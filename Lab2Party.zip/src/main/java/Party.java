/*
	Name: 
	Username: 
*/

public class Party {

}
