/*
	Name: 
	Username: 
*/

public class Hero {
	
}
